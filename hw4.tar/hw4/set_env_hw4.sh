#!/usr/env/bin bash

source /opt/intel/parallel_studio_xe_2018/psxevars.sh
source /opt/intel/vtune_amplifier/amplxe-vars.sh
source /opt/intel/compilers_and_libraries/linux/bin/compilervars.sh -arch intel64 -platform linux 
