#ifndef SP2018_CS377P_ASSIGNMENT3_MEASURE_H
#define SP2018_CS377P_ASSIGNMENT3_MEASURE_H

void start_measurement();
void stop_measurement();

#endif // SP2018_CS377P_ASSIGNMENT3_MEASURE_H
