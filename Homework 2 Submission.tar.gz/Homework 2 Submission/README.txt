Joseph Bess, Krishna Ramdeep

Part 1:
Code: assign2jacobi.m, gauss.m
Instructions: No special instructions. Simply open the scripts in MATLAB and run them.

Part 2:
No code to submit

Part 3:
Code: practice3.m for timestep = 0.025, practice3_2.m for timestep = 0.05
Instructions: No special instructions. Simply open the scripts in MATLAB and run them.

Part 4:
The name of the program file for creating the CSR representation of a graph based on
the DIMACS representation is called CIMACS.cpp.  In order to run this properly,
the second argument must be the file name of the DIMACS file, and the third
argument must either be "push" or "pull" to specify which method to use.
The output on the command line will be the label for the node, as well as the 
value of its rank after convergence.